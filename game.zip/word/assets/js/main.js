


   var i =0;
   var pos=0;
   var nex_word;
   var full_word;
   var tar_id;
   var temp;
   var arr = ['great','light','python','fail','run'];

   var plasma = new Audio("./assets/mp3/plasma.ogg");
   var wrong = new Audio("./assets/mp3/wrong.ogg");
   var blash = new Audio("./assets/mp3/blash.ogg");

   
   $(document).keypress(function(event){
       if(nex_word){
           if(pos+1==arr[tar_id].length){
               if(nex_word==event.key){
                full_word +=arr[tar_id].charAt(pos);
                   temp =  $('#tar'+tar_id).text().replace(full_word,'<font style="color:green">'+full_word+'</font>');
                   $('#tar'+tar_id).html('<span>'+temp+'</span><img src="./assets/img/target.png"/>');
                       shout_box(i,tar_id);
                       setTimeout(() => {
                           blash.play();
                           blash.remove();
               $('#tar'+tar_id).remove();
                       }, 500);
               pos = 0;
               tar_id;
               nex_word = null;
               }
           }else{
               if(nex_word==event.key){
                full_word +=arr[tar_id].charAt(pos);
                   temp =  $('#tar'+tar_id).text().replace(full_word,'<font style="color:green">'+full_word+'</font>');
                   $('#tar'+tar_id).html('<span>'+temp+'</span><img src="./assets/img/target.png"/>');
                   pos=pos+1;
                   console.log(pos,arr[tar_id].length);
                   nex_word = arr[tar_id].charAt(pos);
                       shout_box(i,tar_id);
               }
               else{
                   wrong.play();
               }
           }
       }else{
           for (var j = 0; j < 5; j++) {
               if(event.key.toLowerCase()==arr[j].charAt(0).toLowerCase()){
                full_word = arr[j].charAt(0);
               temp =  $('#tar'+j).text().replace(arr[j].charAt(pos),'<font style="color:green">'+arr[j].charAt(pos)+'</font>');
               $('#tar'+j).html('<span>'+temp+'</span><img src="./assets/img/target.png"/>');
               pos=pos+1;
               console.log(arr[j].charAt(pos));
               nex_word = arr[j].charAt(pos);
               tar_id = j;
                   shout_box(i,tar_id);
                   }
               else{
                   wrong.play();
               }
                   
               
           }
       }
       i++;
   });
   