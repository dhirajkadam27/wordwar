function create_boxes(){
    setTimeout(() => {
    $(".main").append('<div class="target" id="tar0"><span>'+arr[0]+'</span><img src="./assets/img/target.png"/></div>');
    $("#tar0").css({left:$('.spaceship').width()*0.02,top:0});
    }, 150);

    
    setTimeout(() => {
    $(".main").append('<div class="target" id="tar1"><span>'+arr[1]+'</span><img src="./assets/img/target.png"/></div>');
    $("#tar1").css({left:$('.spaceship').width()*0.40,top:0});
    }, 50);

    
    setTimeout(() => {
    $(".main").append('<div class="target" id="tar2"><span>'+arr[2]+'</span><img src="./assets/img/target.png"/></div>');
    $("#tar2").css({left:$('.spaceship').width()*0.80,top:0});
    }, 80);

    
    setTimeout(() => {
    $(".main").append('<div class="target" id="tar3"><span>'+arr[3]+'</span><img src="./assets/img/target.png"/></div>');
    $("#tar3").css({left:$('.spaceship').width()*0.10,top:0});
    }, 120);

    
    setTimeout(() => {
    $(".main").append('<div class="target" id="tar4"><span>'+arr[4]+'</span><img src="./assets/img/target.png"/></div>');
    $("#tar4").css({left:$('.spaceship').width()*0.100,top:0});
    }, 180);
}
function animate_boxes(){
                
    setTimeout(() => {
    $("#tar0").animate({left:($('.spaceship').width()/2)-20,top:$('.spaceship').offset().top}, 60000, 'linear');
    }, 150);

    
    setTimeout(() => {
    $("#tar1").animate({left:($('.spaceship').width()/2)-20,top:$('.spaceship').offset().top}, 64000, 'linear');
    }, 50);

    
    setTimeout(() => {
    $("#tar2").animate({left:($('.spaceship').width()/2)-20,top:$('.spaceship').offset().top}, 67000, 'linear');
    }, 80);

    
    setTimeout(() => {
    $("#tar3").animate({left:($('.spaceship').width()/2)-20,top:$('.spaceship').offset().top}, 62000, 'linear');
    }, 120);

    
    setTimeout(() => {
    $("#tar4").animate({left:($('.spaceship').width()/2)-20,top:$('.spaceship').offset().top}, 68000, 'linear');
    }, 180);

}
