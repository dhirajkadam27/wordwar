function shout_box(p,q){
            
    plasma.play();
        $(".main").append('<img class="ray'+p+' ray" src="./assets/img/plasma.png"/>');
        $(".ray"+p).css({left:$('.spaceship').width()/3,top:$('#ship').offset().top-70});
            $(".ray"+p).animate({left:$("#tar"+q).offset().left-$(".main").offset().left,top:$("#tar"+q).offset().top},500,'linear');
           
             
        setTimeout(() => {
            $(".ray"+p).attr('src','./assets/img/explosion.jpg')
            }, 450);

        setTimeout(() => {
            $(".ray"+p).remove();
            }, 500);
    }
   