var multi1 = new Audio("./assets/mp3/multi-3.ogg");
var multi2 = new Audio("./assets/mp3/multi-2.ogg");

function animate_scr(){
    multi1.play();
    multi2.play();
    $('body').append('<div class="cover"></div>');

    setTimeout(() => {
        $( ".cover" ).animate( {
            backgroundColor: jQuery.Color( "rgb(0, 0, 0)" ),
          }, 1000 );
          setTimeout(() => {
            $( ".cover" ).remove();
            $( ".play" ).remove();
            $( ".main" ).css({'visibility':'visible'});
            create_boxes();
            animate_boxes();
            
            var check_top = setInterval(() => {
              if($('#tar0').length){
              var tart_top0 = $('#tar0').offset().top;
              }else{
                  var tart_top0 = 0;
              }
              if($('#tar1').length){
              var tart_top1 = $('#tar1').offset().top;
              }else{
                  var tart_top1 = 0;
              }
              if($('#tar2').length){
              var tart_top2 = $('#tar2').offset().top;
              }else{
                  var tart_top2 = 0;
              }
              if($('#tar3').length){
              var tart_top3 = $('#tar3').offset().top;
              }else{
                  var tart_top3 = 0;
              }
              if($('#tar4').length){
              var tart_top4 = $('#tar4').offset().top;
              }else{
                  var tart_top4 = 0;
              }

              if(tart_top0==0&&tart_top1==0&&tart_top2==0&&tart_top3==0&&tart_top4==0){
                  clearInterval(check_top);
                  $('.retry').css({display:'block'});
              }
              
              if(tart_top0>=$('.main').height()-100||tart_top1>=$('.main').height()-100||tart_top2>=$('.main').height()-100||tart_top3>=$('.main').height()-100||tart_top4>=$('.main').height()-100){
                  clearInterval(check_top);
                  $('.target').remove();
                  $('.retry').css({display:'block'});
                  console.log("done");
              }else{
                  console.log("not");
              }
          }, 1000);
          
          }, 1000);
    }, 500);
}