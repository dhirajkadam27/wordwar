function splash(){
    $('body').append('<div class="logo"><img id="logo" src="./assets/img/dyp.png"></div>');
    $('body').append('<div class="cover"></div>');

    setTimeout(() => {
        $( ".cover" ).animate( {
            backgroundColor: jQuery.Color( "rgb(0, 0, 0)" ),
          }, 2000 );
    }, 1000);

    setTimeout(() => {
        $( ".cover" ).animate( {
            backgroundColor: jQuery.Color( "rgba(100, 200, 255, 0.0)" ),
          }, 2000 );
        $('#logo').attr('src','./assets/img/logo.png');
        $('body').css({backgroundImage: 'url(./assets/img/bg.jpg)',backgroundSize: 'cover',backdropFilter: 'brightness(0.7)'});
    }, 3000);


    setTimeout(() => {
        $( ".cover" ).animate( {
            backgroundColor: jQuery.Color( "rgb(0, 0, 0)" ),
        }, 2000 );
        setTimeout(() => {
            $( ".cover" ).animate( {
                backgroundColor: jQuery.Color( "rgb(0, 0, 0,0.0)" ),
            }, 2000 );
            $('body').append('<div class="play"><img src="./assets/img/logo.png"><div onclick="play()"><img class="btn_img" src="./assets/img/play.png"></div><div id="about"><img class="btn_img" src="./assets/img/about.png"></div></div>')
            $('.logo').remove();
            $('.cover').remove();
        }, 2000);

    }, 5000);
    
    // setTimeout(() => {
    //     $( ".cover" ).animate( {
    //         backgroundColor: jQuery.Color( "rgb(0, 0, 0)" ),
    //       }, 2000 );
    //       setTimeout(() => {
    //         $('.logo').remove();
    //         $('.cover').remove();
    //         $( ".cover" ).animate( {
    //             backgroundColor: jQuery.Color( "rgb(0, 0, 0,0.0)" ),
    //           }, 1000 );
    //         $('.main').css({'visibility':'visible'});
    //       }, 3000);
    // }, 5000);
}